

#Author: Written from scratch, by God Bennett, AuraHuman Labs founder
#Blender3d addon to enable aurahuman Ai/GPT2 input and response texts as well as associated 3d behaviour 

#How to use:
#1. "I" key : *Initialize* AuraHuman Aeon being.
#2. Right click anywhere in 3d scene (like beside the synth) to enable AuraHuman Aeon Communicate.
#3. "T" key : Start Aeon *thinking*/reading cycle. 
#4. "R" key : Get *response* from Aeon being.


bl_info = {
    "name": "AuraHuman Aeon Communicate",
    "author": "God Bennett",
    "version": (1, 0),
    "blender": (2, 91, 0),
    "location_": "Right click anywhere in scene > Object Context Menu > AuraHuman Aeon Communicate",
    "location" : "[1]'I' key : *Initialize*, [2]Right click anywhere in scene/send message, [3]'T' key start Aeon think cycle, [4]'R' key get Aeon *response*",
    "description": "AuraHuman Aeon is a sequence of artificial intelligence powered 3d beings - Crypto Art NFTs you can actually hold a conversation with.", 
    "warning": "",
    "doc_url": "facebook.com/GodEngineer"
}


########################################################
#BLOCK_A. Conversational Neural Network Module 
#Note 1: Setup function is invoked in aeonInitializeBeing (), before 3d model realism is invoked
#Note 2: Neural network/ai response is called in "UserTransmission" class @execute func, where aeon_output variable is updated.
from . import interact_aurahuman
from . import sound_player

CONVERSATIONAL_NEURAL_NETWORK = interact_aurahuman.NeuralNetConversationalModule()


########################################################
#BLOCK_B. AuraHuman Blender3d Modules
import bpy
from bpy.types import Operator, AddonPreferences
from bpy.props import StringProperty

SPEECH_USAGE_INDEX = 0

def updateSpeechUsageIndex():
    global SPEECH_USAGE_INDEX
    SPEECH_USAGE_INDEX += 1

    if ( SPEECH_USAGE_INDEX > 1 ):
        SPEECH_USAGE_INDEX = 0

def aeonInitializeBeing (context):
    # play ambience music
    # Set the path to your MP3 file
    AMBIENCE = sound_player.SPEECH_WORKING_FILE + "\\allen_grey.mp3"
    # Call the function to play the music
    sound_player.play_music(AMBIENCE)

    CONVERSATIONAL_NEURAL_NETWORK.setup()
    #...3. Disable skin colour, to place more focus on EYES
    bpy.data.images["Std_Skin_Head_Diffuse"].colorspace_settings.name = 'Non-Color'
    
    bpy.context.scene.render.engine = 'BLENDER_EEVEE'
	
    bpy.data.objects['Point.002'].data.energy = 30
    
    #B. Enable God Bennett's original "photorealistic" fidelity/graphics
    for area in bpy.context.screen.areas: 
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            if space.type == 'VIEW_3D':
                space.shading.type = 'MATERIAL'

    

def printToBlenderConsole(data):
    for window in bpy.context.window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type == 'CONSOLE':
                override = {'window': window, 'screen': screen, 'area': area}
                bpy.ops.console.scrollback_append(override, text=str(data), type="OUTPUT")   
                


class AuraHumanInitialization(bpy.types.Operator):
    bl_idname = "aurahuman.initialization"
    bl_label = "AuraHuman Aeon Initialization"
    bl_options = {'REGISTER', 'UNDO'}

    initializationMessage = bpy.props.StringProperty(name="")

    def execute(self, context):
        aeonInitializeBeing(context)

        return {'FINISHED'}




def _aeon_3d_action_begin_read_behaviour():
    
    #simulate reading movement
    
    #A. Prepare model for animation
    #Focus on eyes, which animate to do reading action
    #...1. Disable MATERIAL mode (Disable God Bennett's original "photorealistic" fidelity/graphics)
    for area in bpy.context.screen.areas: 
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            if space.type == 'VIEW_3D':
                space.shading.type = 'MATERIAL'
    #...2. Disable light/focus on overall synth, to place more focus on EYES
    bpy.data.objects['Point.002'].data.energy = 0
    #...3. Disable skin colour, to place more focus on EYES
    bpy.data.images["Std_Skin_Head_Diffuse"].colorspace_settings.name = 'Non-Color'
  
    
    #B. Start animation
    bpy.ops.screen.animation_play() 

    

def _aeon_3d_action_end_read_behaviour ():
    
    #simulate stop reading movement
    
    #A. Restore still state
    bpy.ops.screen.animation_cancel(restore_frame=True)
    bpy.ops.scene.frame_current = 0 #God Bennett's lucky guess, this reset's animation frame to 0
    
                
    #Re-focus on entire synth which restores default position prior to animation to do reading action
    
    #...2. Enable MATERIAL mode (Enable God Bennett's original "photorealistic" fidelity/graphics)
    for area in bpy.context.screen.areas: 
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            if space.type == 'VIEW_3D':
                space.shading.type = 'MATERIAL'
    #...2. Restore point light/focus on synth
    bpy.data.objects['Point.002'].data.energy = 100
    #...3. Restore default skin colour, to restore focus on entire synth
    """
    #bpy.data.images["Std_Skin_Head_Diffuse"].colorspace_settings.name = 'sRGB'
    """
      

def _aeon_3d_action_response_sequence ():
    bpy.app.timers.register(_aeon_3d_action_begin_read_behaviour, first_interval=1)
    bpy.app.timers.register(_aeon_3d_action_end_read_behaviour, first_interval=7)
    
class UserTransmission(bpy.types.Operator):
    bl_idname = "user.transmission"
    bl_label = "User Transmission"
    bl_options = {'REGISTER', 'UNDO'}

    #initializationMessage = bpy.props.StringProperty(name="")

    def execute(self, context):
        _aeon_3d_action_response_sequence()
        bpy.types.VIEW3D_MT_object_context_menu.prepend(AuraHumanDialogFunc)
        wm_c = bpy.context.window_manager
        km_c = wm_c.keyconfigs.addon.keymaps.new(name='Object Mode', space_type='EMPTY')
        kmi_c = km_c.keymap_items.new(AuraHumanDialog.bl_idname, 'R', 'PRESS', ctrl=False, shift=False)
        #kmi_c.properties.aeon_output = "wtf!"
        #AEON_INPUT = kmi_c.properties.user_input #This does not reflect latest user input!
        LATEST_AEON_INPUT = bpy.context.window_manager.operator_properties_last("aurahuman.dialog")
        LATEST_AEON_INPUT = LATEST_AEON_INPUT.user_input
        #printToBlenderConsole(AEON_INPUT)
        kmi_c.properties.aeon_output = interact_aurahuman.getNeuralNetConversationalResponse ( LATEST_AEON_INPUT, CONVERSATIONAL_NEURAL_NETWORK )
        addon_keymaps_communicate_with_aeon_being.append(km_c)
        #lipsync cycle invocation
        #Invoke classes and execute functions here
        bpy.ops.object.delete_sound_strips()

        sound_player.genSpeech(kmi_c.properties.aeon_output, SPEECH_USAGE_INDEX)
        updateSpeechUsageIndex()

    
        bpy.ops.object.add_sound_strip()
        bpy.ops.object.select_armature()
        bpy.ops.object.toggle_rhubarb()
        bpy.ops.object.play_aeon_speech_sequencer()


        return {'FINISHED'}

class AuraHumanDialog(bpy.types.Operator):
    bl_idname = "aurahuman.dialog"
    bl_label = "AuraHuman Aeon Dialog"
    bl_options = {'REGISTER', 'UNDO'}

    user_input = bpy.props.StringProperty(name="User Input", default="<To be sent to Synth-Aeon>")
    aeon_output = bpy.props.StringProperty(name="Aeon Output", default="<To be replied by Synth-Aeon>")

    
    def execute(self, context):
        pass

        return {'FINISHED'}
    

           
# store keymaps here to access after registration
addon_keymaps_communicate_with_aeon_being = []
addon_keymaps_init_aeon_being = []




class DeleteSoundStripsOperator(bpy.types.Operator):
    bl_idname = "object.delete_sound_strips"
    bl_label = "Delete Sound Strips"
    
    def execute(self, context):
        # Save current scene type
        
        saved_scene_type = bpy.context.scene.render.engine
        print("<<<<<<<<<<<< saved_scene_type >>>>>>>>> " + str(saved_scene_type))

        # Remove sound strips from sequencer
        scene = bpy.context.scene
        for strip in scene.sequence_editor.sequences:
            if strip.type == 'SOUND' and "speech" in strip.name.lower(): #remove only sounds with speech
                scene.sequence_editor.sequences.remove(strip)

        # Reset scene type
        bpy.context.scene.render.engine = saved_scene_type
            
        return {'FINISHED'}

class AddSoundStripOperator(bpy.types.Operator):
    bl_idname = "object.add_sound_strip"
    bl_label = "Add Sound Strip"


    def execute(self, context):
        # Save current scene type
        saved_scene_type = bpy.context.scene.render.engine

        # add last aeon speech sound strip
        #bpy.context.area.type = 'SEQUENCE_EDITOR'
        sequencer = bpy.context.scene.sequence_editor

        SPEECH_FILE_NAME = ""
        if ( SPEECH_USAGE_INDEX == 1 ):
            SPEECH_FILE_NAME 
            SPEECH_FILE_NAME = "\\speech_n_plus.wav"
        if ( SPEECH_USAGE_INDEX == 0 ):
            SPEECH_FILE_NAME = "\\speech_n.wav"
        #Note usage index is needed because I found that we can't delete and override last speech file as blender would have it in the sequencer
        #even shortly after deletion. Solution is to cycle between creating two files, deleting the one not in use.
            
        _sound_dir_file = sound_player.SPEECH_WORKING_FILE + SPEECH_FILE_NAME


        sequence_editor = bpy.data.scenes[0].sequence_editor
        sequence_editor.sequences.new_sound(name="Aeon Speech", filepath=_sound_dir_file, channel=1, frame_start=1)

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='POSE')

        
        # Reset scene type
        bpy.context.scene.render.engine = saved_scene_type

        
        return {'FINISHED'}

class SelectArmatureOperator(bpy.types.Operator):
    bl_idname = "object.select_armature"
    bl_label = "Select Armature"
    
    def execute(self, context):
        armature_name = "FaceitRig"
        armature_object = bpy.data.objects.get(armature_name)
        
        if armature_object is not None:
            #bpy.ops.object.mode_set(mode='OBJECT')
            #bpy.ops.object.select_all(action='DESELECT')
            armature_object.select_set(True)
            bpy.context.view_layer.objects.active = armature_object
            #bpy.ops.object.mode_set(mode='POSE') #needed because (next operator) rhubarb button is active only in pose mode
            print(f"Armature '{armature_name}' selected and switched to Pose Mode.")
        else:
            print(f"Armature '{armature_name}' not found.")
        
        return {'FINISHED'}

class ToggleRhubarbOperator(bpy.types.Operator):
    bl_idname = "object.toggle_rhubarb"
    bl_label = "Toggle Rhubarb"
    
    def execute(self, context):
        bpy.ops.object.rhubarb_lipsync()
        #bpy.ops.object.mode_set(mode='OBJECT') #Reset mode to object to enable AeonSynth re-init (re-init not neccessary now)
        print("Button pressed successfully.")
        
        return {'FINISHED'}



class PlayAeonSpeechOperator(bpy.types.Operator):
    bl_idname = "object.play_aeon_speech_sequencer"
    bl_label = "Play Aeon Speech Sequencer"
    
        
    def execute(self, context):
        # Save current scene type
        saved_scene_type = bpy.context.scene.render.engine

        # Play sound strip
        # play sound strip frame 1 sound, last aeon speech
        #bpy.context.area.type = 'SEQUENCE_EDITOR'
        sequencer = bpy.context.scene.sequence_editor
        
        for strip in sequencer.sequences:
            if strip.type == 'SOUND':
                strip.frame_final_start = 1
        bpy.context.scene.frame_set(1)
        bpy.ops.screen.animation_play()

        bpy.ops.object.mode_set(mode='OBJECT')

        # Reset scene type
        bpy.context.scene.render.engine = saved_scene_type
            
        return {'FINISHED'}

# addon sound working dir pref
class AuraHumanAddonPreferences(AddonPreferences):
    bl_idname = __name__

    addon_directory: StringProperty(
        name="Speech Working Directory",
        subtype='DIR_PATH',
        default="C:\\Backup\\Downloads\\God\\RobotizeJA\\JAIA\\aura\\synth\\aura_human_0000\\aura_human_blender\\sounds"
        )

    #default="C:\\Users\\bennettgq\\Documents\\_______JAIA\aura_human\aura_human_0000\\aura_human_blender\\sounds"
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "addon_directory")
        
        # Set sound_player.SPEECH_WORKING_FILEs to the active addon directory
        sound_player.SPEECH_WORKING_FILE = self.addon_directory
        print("work file >>>>>>>" + str(sound_player.SPEECH_WORKING_FILE))
        
def AuraHumanDialogFunc(self, context):
    self.layout.operator(AuraHumanDialog.bl_idname)
  
def register():
    # lipsync registrations
    bpy.utils.register_class(DeleteSoundStripsOperator)
    bpy.utils.register_class(AddSoundStripOperator)
    bpy.utils.register_class(SelectArmatureOperator)
    bpy.utils.register_class(ToggleRhubarbOperator)
    bpy.utils.register_class(PlayAeonSpeechOperator)
    
    bpy.utils.register_class(AuraHumanAddonPreferences)
    ################################
    ################Communication
    bpy.utils.register_class(UserTransmission)
    bpy.utils.register_class(AuraHumanDialog)
    bpy.types.VIEW3D_MT_object_context_menu.prepend(AuraHumanDialogFunc)
    
    
    #keymap for communication
    wm_c = bpy.context.window_manager
    km_c = wm_c.keyconfigs.addon.keymaps.new(name='Object Mode', space_type='EMPTY')
    kmi_c = km_c.keymap_items.new(UserTransmission.bl_idname, 'T', 'PRESS', ctrl=False, shift=False)
    #kmi_c.properties.initializationMessage = "Initialization complete!"
    addon_keymaps_communicate_with_aeon_being.append(km_c)
    
    ################################
    ################initialization
    bpy.utils.register_class(AuraHumanInitialization)
    
    #keymap for initialization
    
    wm_i = bpy.context.window_manager
    km_i = wm_i.keyconfigs.addon.keymaps.new(name='Object Mode', space_type='EMPTY')
    kmi_i= km_i.keymap_items.new(AuraHumanInitialization.bl_idname, 'I', 'PRESS', ctrl=False, shift=False)
    kmi_i.properties.initializationMessage = "Initialization complete!"
    addon_keymaps_init_aeon_being.append(km_i)


    
def unregister():
    bpy.utils.unregister_class(AuraHumanAddonPreferences)
    bpy.utils.unregister_class(AuraHumanDialog)
    bpy.types.VIEW3D_MT_object.remove(AuraHumanDialogFunc)
    bpy.utils.unregister_class(AuraHumanInitialization)
    """
    # handle the keymap
    wm = bpy.context.window_manager
    for km in addon_keymaps:
        wm.keyconfigs.addon.keymaps.remove(km)
    # clear the list
    del addon_keymaps[:]
    """
    # lipsync de-registrations
    bpy.utils.unregister_class(DeleteSoundStripsOperator)
    bpy.utils.unregister_class(AddSoundStripOperator)
    bpy.utils.unregister_class(SelectArmatureOperator)
    bpy.utils.unregister_class(ToggleRhubarbOperator)
    bpy.utils.unregister_class(PlayAeonSpeechOperator)



if __name__ == "__main__":
    register()

