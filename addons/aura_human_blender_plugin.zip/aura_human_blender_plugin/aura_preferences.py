import bpy
from bpy.types import AddonPreferences
from bpy.props import StringProperty
from bpy.props import EnumProperty
from platform import system

class AuraHumanAddonPreferences(AddonPreferences):
    bl_idname = __package__

    sound_work_dir : StringProperty(
        name="Aura Human Speech Working Directory",
        subtype='FILE_PATH',
        default=bpy.utils.user_resource('SCRIPTS', path="addons") + '/blender-rhubarb-lipsync/bin/rhubarb' + ('.exe' if system() == 'Windows' else '')
        )

   
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "sound_work_dir")

def register():
    bpy.utils.register_class(AuraHumanAddonPreferences)


def unregister():
    bpy.utils.unregister_class(AuraHumanAddonPreferences)
