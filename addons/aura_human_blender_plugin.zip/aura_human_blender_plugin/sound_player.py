import pyttsx3
import os
import bpy
import subprocess

SPEECH_ENGINE = pyttsx3.init() # object creation

SPEECH_WORKING_FILE = "_____"

#dev_test
SPEECH_WORKING_FILE_TEST = "C:\\Backup\\Downloads\\God\\RobotizeJA\\JAIA\\aura\\synth\\aura_human_0000\\aura_human_blender\\sounds"
#SPEECH_WORKING_FILE_TEST = "C:\\Users\\bennettgq\\Documents\\_______JAIA\\aura_human\\aura_human_0000\\aura_human_blender\\sounds"


""" RATE"""
rate = SPEECH_ENGINE.getProperty('rate')   # getting details of current speaking rate
print (rate)                        #printing current voice rate
SPEECH_ENGINE.setProperty('rate', 125)     # setting up new voice rate


"""VOLUME"""
volume = SPEECH_ENGINE.getProperty('volume')   #getting to know current volume level (min=0 and max=1)
print (volume)                          #printing current volume level
SPEECH_ENGINE.setProperty('volume',1.0)    # setting up volume level  between 0 and 1

"""VOICE"""
voices = SPEECH_ENGINE.getProperty('voices')       #getting details of current voice
#engine.setProperty('voice', voices[0].id)  #changing index, changes voices. o for male
SPEECH_ENGINE.setProperty('voice', voices[1].id)   #changing index, changes voices. 1 for female


def speak (text):
    SPEECH_ENGINE.say(text)
    SPEECH_ENGINE.runAndWait()
    SPEECH_ENGINE.stop()

def genSpeech (text, usageIndex):

    fileNameCycN ="\\speech_n.wav"
    fileNameCycN_Plus = "\\speech_n_plus.wav"


    if(usageIndex==0):
        filePath=SPEECH_WORKING_FILE_TEST+ fileNameCycN_Plus
        delPath=SPEECH_WORKING_FILE_TEST+ fileNameCycN_Plus
    if(usageIndex==1):
        filePath=SPEECH_WORKING_FILE_TEST+ fileNameCycN
        delPath=SPEECH_WORKING_FILE_TEST+ fileNameCycN

        
    if os.path.exists(delPath):
        os.remove(delPath)
        print(f"File '{delPath}' deleted.")
    else:
        print(f"File '{delPath}' does not exist.")
        
    # We can use file extension as mp3 and wav, both will work
    SPEECH_ENGINE.save_to_file(add_filler_words(text), filePath)
    SPEECH_ENGINE.runAndWait()
    SPEECH_ENGINE.stop()



def genSpeechTest (testDir, text):
    # We can use file extension as mp3 and wav, both will work
    SPEECH_ENGINE.save_to_file(add_filler_words(text), testDir + "\\speech_n.wav")
    SPEECH_ENGINE.runAndWait()
    SPEECH_ENGINE.stop()


import random

def add_filler_words(text, filler_words=['um', 'ah', 'you know'], probability=0.1):
    """
    Add filler words like "um" and "ah" to the given text with a certain probability.
    
    Args:
    text (str): The input text.
    filler_words (list): List of filler words to choose from.
    probability (float): Probability of adding a filler word at each word boundary.
    
    Returns:
    str: The text with added filler words.
    """
    words = text.split()
    result = []
    for word in words:
        result.append(word)
        if random.random() < probability:
            filler_word = random.choice(filler_words)
            result.append(filler_word)
    return ' '.join(result)


def play_music(filepath):
    try:
        # Construct the command to play the MP3 file using the system's default media player
        command = ['start', filepath]
        
        # Execute the command using subprocess
        subprocess.Popen(command, shell=True)
        print("Playing music...")
    except Exception as e:
        print("Error:", e)


# Example usage
generated_text = "This is some generated text. It may sound robotic."
text_with_fillers = add_filler_words(generated_text)
#print(text_with_fillers)

"""
#Intialize ambience
import pygame
pygame.init()
pygame.mixer.init()
sound = pygame.mixer.Sound(SPEECH_WORKING_FILE + "\\allen_grey.wav")
sound.set_volume(0.3)
sound.play() 
"""
